import React from 'react';

function Dev() {
  return (
    <div className='dev'>
      Component Dev
    </div>
  );
}

export default Dev;
