import React, { useState } from 'react'

const Index = () => {
    const [counter,setCounter] = useState();
  return (
    <div>
      
    </div>
  )
}

export default Index
