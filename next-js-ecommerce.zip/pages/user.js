import React from 'react'

const user = () => {
  return (
    <div>
        <h1>User page   </h1>
    </div>
  )
}

export default user
